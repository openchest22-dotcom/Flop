Flop kurulumu:
İndirdiğiniz flop1.0.tar.gz dosyasını bir dizine çıkarın.
Çıkardığınız dizine girin.
sudo cp flop /usr/local/bin/ komutu ile sistem ve uygulamalrın bulunduğu klasöre kopyalayın
Kısayollar:
CTRL + X = Kaydedilir ve çıkılır
CTRL + E = Kaydedilmeden çıkılır 
CTRL + P =Tüm dosyayı temizler
CTRL + F = Dosyada arama yapar